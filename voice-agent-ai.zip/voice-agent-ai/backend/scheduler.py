"""
scheduler.py  ──  Automated Call Scheduler (Agentic Loop)
Uses APScheduler to run the agent loop every day.
Agent loop: Observe (check DB) → Reason (who to call) → Act (make calls)
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
import asyncio
import logging

from database import get_due_customers, update_call_status, log_call
from voice_call import make_call
from config import TWILIO_ACCOUNT_SID

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()


async def run_daily_reminders():
    """
    Main agentic loop — runs daily at 10:00 AM.
    1. Observe: fetch customers with upcoming EMI
    2. Reason:  filter by risk + not already called
    3. Act:     place calls via Twilio
    """
    logger.info(f"[{datetime.now()}] Starting daily EMI reminder run...")

    if not TWILIO_ACCOUNT_SID:
        logger.warning("Twilio not configured. Simulating calls (dry run).")
        customers = get_due_customers()
        for c in customers:
            logger.info(f"  [DRY RUN] Would call {c['name']} at {c['phone']}")
        logger.info(f"Dry run complete. {len(customers)} customers would be called.")
        return

    customers = get_due_customers()
    call_count = 0

    for customer in customers:
        # Skip if already called today
        if customer.get("call_status") in ("called", "payment_promised"):
            continue

        logger.info(f"Calling {customer['name']} at {customer['phone']}...")
        result = make_call(customer["customer_id"], customer["phone"])

        if result["success"]:
            update_call_status(customer["customer_id"], "calling")
            log_call(
                customer_id=customer["customer_id"],
                call_sid=result["call_sid"],
                transcript="",
                decision="initiated",
                outcome="call_placed",
            )
            call_count += 1
            await asyncio.sleep(2)   # small delay between calls
        else:
            logger.error(f"Call failed for {customer['name']}: {result.get('error')}")

    logger.info(f"Daily run complete. {call_count} calls placed.")


def start_scheduler():
    """Start the background scheduler."""
    scheduler.add_job(
        run_daily_reminders,
        trigger=CronTrigger(hour=10, minute=0),   # 10:00 AM daily
        id="daily_emi_reminders",
        replace_existing=True,
    )
    scheduler.start()
    logger.info("Scheduler started. EMI reminders will run daily at 10:00 AM.")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logger.info("Scheduler stopped.")


async def trigger_manual_run():
    """Manually trigger the agent loop (for testing/admin use)."""
    await run_daily_reminders()
