"""
agent.py  ──  AI Decision Engine
Uses Groq (free) + LangChain to classify customer responses
and decide next actions in the agentic loop.
"""
from langchain_groq import ChatGroq
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from config import GROQ_API_KEY

# ─── Decision constants ───────────────────────────────────────────────────
PAYMENT_PROMISED = "PAYMENT_PROMISED"
NEED_EXTENSION   = "NEED_EXTENSION"
REFUSED          = "REFUSED"
ESCALATE_HUMAN   = "ESCALATE_HUMAN"
UNCLEAR          = "UNCLEAR"
NO_ANSWER        = "NO_ANSWER"

VALID_DECISIONS = {
    PAYMENT_PROMISED, NEED_EXTENSION,
    REFUSED, ESCALATE_HUMAN, UNCLEAR, NO_ANSWER
}

# ─── Rule-based fallback (no API key needed) ──────────────────────────────

def rule_based_decision(text: str) -> str:
    """Simple keyword classifier used when Groq key is not set."""
    t = text.lower()
    if any(w in t for w in ["pay tomorrow", "will pay", "paying", "paid", "transfer"]):
        return PAYMENT_PROMISED
    if any(w in t for w in ["extension", "more time", "delay", "later", "next month"]):
        return NEED_EXTENSION
    if any(w in t for w in ["cannot", "won't", "not paying", "refuse", "lost job"]):
        return NEED_EXTENSION   # route to human rather than hard REFUSED
    if any(w in t for w in ["manager", "supervisor", "human", "person"]):
        return ESCALATE_HUMAN
    if not text.strip():
        return NO_ANSWER
    return UNCLEAR


# ─── LangChain + Groq agent ───────────────────────────────────────────────

DECISION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an EMI collection assistant for a loan company.
A customer just spoke to you on a phone call.
Analyze their response and return EXACTLY ONE of these decisions (just the label, nothing else):

PAYMENT_PROMISED   - customer confirmed they will pay
NEED_EXTENSION     - customer asked for more time or cannot pay right now
REFUSED            - customer explicitly refused to pay
ESCALATE_HUMAN     - customer is upset, asking for manager, or situation is complex
NO_ANSWER          - customer did not speak or call was silent
UNCLEAR            - response doesn't fit other categories

Customer context:
- Name: {customer_name}
- EMI Amount: ₹{emi_amount}
- Due Date: {due_date}
- Missed Payments: {missed_payments}
- Risk Score: {risk_score}/1.0

Customer said: "{customer_response}"

Return only the decision label."""),
    ("human", "What is the decision?")
])

RESPONSE_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a professional, empathetic EMI reminder voice agent.
Generate a short, natural spoken response (2-3 sentences max) based on the decision.
Be polite, clear and concise. Do NOT use any special characters or markdown.

Customer: {customer_name}
EMI: ₹{emi_amount} due on {due_date}
Decision: {decision}

Generate appropriate response:
- PAYMENT_PROMISED: Thank them and confirm the date
- NEED_EXTENSION: Acknowledge and offer to connect with team
- REFUSED: Remain polite, note consequences gently
- ESCALATE_HUMAN: Acknowledge and say a specialist will call back
- NO_ANSWER: Leave a brief voicemail-style message
- UNCLEAR: Politely ask to confirm their payment intent"""),
    ("human", "Generate the voice response now.")
])


def get_llm():
    if not GROQ_API_KEY:
        return None
    try:
        return ChatGroq(
            api_key=GROQ_API_KEY,
            model="llama-3.1-8b-instant",   # free & fast
            temperature=0.1,
            max_tokens=200,
        )
    except Exception:
        return None


def decide_action(customer_response: str, customer: dict) -> str:
    """
    Returns one of the VALID_DECISIONS strings.
    Falls back to rule-based if no Groq key.
    """
    if not GROQ_API_KEY:
        return rule_based_decision(customer_response)

    llm = get_llm()
    if not llm:
        return rule_based_decision(customer_response)

    try:
        chain = DECISION_PROMPT | llm | StrOutputParser()
        result = chain.invoke({
            "customer_name":     customer.get("name", "Customer"),
            "emi_amount":        customer.get("emi_amount", 0),
            "due_date":          customer.get("emi_due_date", ""),
            "missed_payments":   customer.get("missed_payments", 0),
            "risk_score":        customer.get("risk_score", 0),
            "customer_response": customer_response,
        })
        decision = result.strip().upper()
        return decision if decision in VALID_DECISIONS else rule_based_decision(customer_response)
    except Exception:
        return rule_based_decision(customer_response)


def generate_response(decision: str, customer: dict) -> str:
    """
    Generate a natural language voice response for the customer.
    Falls back to template responses if no Groq key.
    """
    name   = customer.get("name", "Customer").split()[0]   # first name
    amount = customer.get("emi_amount", 0)
    date   = customer.get("emi_due_date", "")

    # Template fallbacks (always available)
    templates = {
        PAYMENT_PROMISED: f"Thank you {name}! We have noted that you will make the payment. "
                          f"Please ensure the EMI of rupees {amount} is paid by {date}. Have a great day!",
        NEED_EXTENSION:   f"I understand {name}. We will have our team reach out to discuss a suitable payment arrangement. "
                          f"Please expect a call from us shortly.",
        REFUSED:          f"{name}, we understand your situation. However, please note that missed payments may affect your credit score. "
                          f"Our team will be in touch to help resolve this.",
        ESCALATE_HUMAN:   f"Of course {name}. I will connect you with a senior specialist who can better assist you. "
                          f"Please expect a call within the next few hours.",
        NO_ANSWER:        f"Hello {name}, this is a reminder that your EMI of rupees {amount} is due on {date}. "
                          f"Please call us back or make the payment at your earliest convenience. Thank you.",
        UNCLEAR:          f"Thank you for your response {name}. To confirm, are you able to make the payment of "
                          f"rupees {amount} by {date}? Please press 1 for yes or say yes.",
    }

    if not GROQ_API_KEY:
        return templates.get(decision, templates[UNCLEAR])

    llm = get_llm()
    if not llm:
        return templates.get(decision, templates[UNCLEAR])

    try:
        chain = RESPONSE_PROMPT | llm | StrOutputParser()
        return chain.invoke({
            "customer_name": name,
            "emi_amount":    amount,
            "due_date":      date,
            "decision":      decision,
        }).strip()
    except Exception:
        return templates.get(decision, templates[UNCLEAR])


def determine_next_action(decision: str) -> dict:
    """
    Return the next step the system should take after the decision.
    This is the 'agentic loop' — Observe → Reason → Act.
    """
    actions = {
        PAYMENT_PROMISED: {
            "action":      "update_db_and_wait",
            "db_status":   "payment_promised",
            "follow_up":   "3_days",
            "notify_team": False,
        },
        NEED_EXTENSION:   {
            "action":      "schedule_human_callback",
            "db_status":   "needs_extension",
            "follow_up":   "1_day",
            "notify_team": True,
        },
        REFUSED:          {
            "action":      "escalate_immediately",
            "db_status":   "refused",
            "follow_up":   "immediate",
            "notify_team": True,
        },
        ESCALATE_HUMAN:   {
            "action":      "escalate_immediately",
            "db_status":   "escalated",
            "follow_up":   "immediate",
            "notify_team": True,
        },
        NO_ANSWER:        {
            "action":      "retry_call",
            "db_status":   "no_answer",
            "follow_up":   "2_hours",
            "notify_team": False,
        },
        UNCLEAR:          {
            "action":      "retry_with_clarification",
            "db_status":   "unclear",
            "follow_up":   "1_day",
            "notify_team": False,
        },
    }
    return actions.get(decision, actions[UNCLEAR])
