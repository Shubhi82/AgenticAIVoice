"""
voice_call.py  ──  Real Phone Call Engine via Twilio
Twilio free trial: https://www.twilio.com/try-twilio
- Sign up → get $15 credit → get a phone number
- Twilio calls your customer's phone
- Customer picks up → Twilio hits your /twiml/greeting webhook
- Our FastAPI returns TwiML XML with the voice message
- Customer speaks → Twilio transcribes → hits /twiml/handle_response
- LangChain agent decides → we return TwiML response
"""
from twilio.rest import Client
from twilio.twiml.voice_response import VoiceResponse, Gather
from twilio.base.exceptions import TwilioRestException

from config import (
    TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN,
    TWILIO_PHONE_NUMBER, PUBLIC_URL
)


def get_twilio_client():
    if not TWILIO_ACCOUNT_SID or not TWILIO_AUTH_TOKEN:
        raise ValueError(
            "Twilio credentials not set. "
            "Add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER "
            "to your .env file. Free trial at https://www.twilio.com/try-twilio"
        )
    return Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)


def make_call(customer_id: str, to_phone: str) -> dict:
    """
    Place a real outbound call to the customer.
    Twilio will hit PUBLIC_URL/twiml/greeting when customer picks up.
    """
    client = get_twilio_client()
    webhook_url = f"{PUBLIC_URL}/twiml/greeting?customer_id={customer_id}"

    try:
        call = client.calls.create(
            to=to_phone,
            from_=TWILIO_PHONE_NUMBER,
            url=webhook_url,
            method="POST",
            status_callback=f"{PUBLIC_URL}/twiml/status?customer_id={customer_id}",
            status_callback_method="POST",
            timeout=30,        # ring for 30 seconds
            machine_detection="Enable",   # detect answering machines
        )
        return {
            "success":  True,
            "call_sid": call.sid,
            "status":   call.status,
            "to":       to_phone,
        }
    except TwilioRestException as e:
        return {
            "success": False,
            "error":   str(e),
            "to":      to_phone,
        }


# ─── TwiML builders (XML that Twilio reads over the call) ─────────────────

def twiml_greeting(customer_name: str, emi_amount: float,
                   due_date: str, customer_id: str) -> str:
    """
    Initial greeting TwiML.
    Twilio reads this aloud to the customer, then listens for their response.
    Uses Twilio's built-in Polly TTS — no Coqui needed!
    """
    first_name = customer_name.split()[0]
    resp = VoiceResponse()

    # Use Amazon Polly voice for natural sound
    with resp.gather(
        input="speech",
        action=f"{PUBLIC_URL}/twiml/handle_response?customer_id={customer_id}",
        method="POST",
        speechTimeout="3",
        language="en-IN",        # Indian English
        enhanced=True,
    ) as gather:
        gather.say(
            f"Hello {first_name}! This is an automated reminder from your loan provider. "
            f"Your EMI payment of Rupees {int(emi_amount)} is due on {due_date}. "
            f"Please say yes to confirm you will make the payment, "
            f"or say no if you need more time.",
            voice="Polly.Aditi",   # Indian English voice
            language="en-IN",
        )

    # If no input received
    resp.say(
        "We did not receive a response. We will try again later. "
        "Thank you. Goodbye.",
        voice="Polly.Aditi",
        language="en-IN",
    )
    return str(resp)


def twiml_follow_up(agent_response: str, decision: str,
                    customer_id: str) -> str:
    """
    Follow-up TwiML after receiving customer's speech.
    Reads the agent's response back to the customer.
    """
    resp = VoiceResponse()

    if decision in ("UNCLEAR", "NO_ANSWER"):
        # Ask again if unclear
        with resp.gather(
            input="speech",
            action=f"{PUBLIC_URL}/twiml/handle_response?customer_id={customer_id}&retry=true",
            method="POST",
            speechTimeout="3",
            language="en-IN",
        ) as gather:
            gather.say(agent_response, voice="Polly.Aditi", language="en-IN")
    else:
        resp.say(agent_response, voice="Polly.Aditi", language="en-IN")
        resp.say("Thank you. Goodbye.", voice="Polly.Aditi", language="en-IN")
        resp.hangup()

    return str(resp)


def twiml_voicemail(customer_name: str, emi_amount: float, due_date: str) -> str:
    """TwiML for when an answering machine is detected."""
    first_name = customer_name.split()[0]
    resp = VoiceResponse()
    resp.pause(length=2)   # wait for beep
    resp.say(
        f"Hello {first_name}, this is an automated EMI reminder. "
        f"Your payment of Rupees {int(emi_amount)} is due on {due_date}. "
        f"Please make the payment or call us back. Thank you.",
        voice="Polly.Aditi",
        language="en-IN",
    )
    return str(resp)


def get_call_status(call_sid: str) -> dict:
    """Fetch live status of a call from Twilio."""
    try:
        client = get_twilio_client()
        call = client.calls(call_sid).fetch()
        return {
            "status":   call.status,
            "duration": call.duration,
            "direction": call.direction,
        }
    except Exception as e:
        return {"status": "unknown", "error": str(e)}
