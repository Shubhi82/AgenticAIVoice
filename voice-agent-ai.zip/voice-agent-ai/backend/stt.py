"""
stt.py  ──  Speech-to-Text using OpenAI Whisper
Works with Python 3.12 ✅
Used for testing: upload .wav/.mp3 → get text
In real phone calls, Twilio handles STT automatically via <Gather input="speech">
"""
import os
import tempfile

_whisper_model = None   # lazy-load: big download, only load when needed


def _load_model():
    global _whisper_model
    if _whisper_model is None:
        import whisper
        _whisper_model = whisper.load_model("base")   # ~140 MB, runs on CPU
    return _whisper_model


def transcribe_audio(audio_path: str) -> str:
    """
    Convert an audio file to text using Whisper.
    Supports: .wav, .mp3, .m4a, .ogg, .flac
    """
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    model = _load_model()
    result = model.transcribe(audio_path, language="en", fp16=False)
    return result["text"].strip()


def transcribe_bytes(audio_bytes: bytes, suffix: str = ".wav") -> str:
    """Transcribe raw audio bytes (from file upload)."""
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name
    try:
        return transcribe_audio(tmp_path)
    finally:
        os.unlink(tmp_path)
