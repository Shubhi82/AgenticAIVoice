import os
from dotenv import load_dotenv

load_dotenv()

# ─── Twilio (Free Trial at twilio.com) ─────────────────────────────────────
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN  = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER", "")   # e.g. +15551234567

# ─── Groq (Free at console.groq.com) ──────────────────────────────────────
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

# ─── Public backend URL (use ngrok locally, Render in prod) ───────────────
# Twilio needs a public URL to call your webhooks
PUBLIC_URL = os.getenv("PUBLIC_URL", "http://localhost:8000")

# ─── App settings ──────────────────────────────────────────────────────────
DATABASE_PATH   = os.getenv("DATABASE_PATH", "data/customers.db")
CSV_UPLOAD_DIR  = os.getenv("CSV_UPLOAD_DIR", "data/uploads")
EMI_DUE_DAYS    = int(os.getenv("EMI_DUE_DAYS", "3"))   # Remind if EMI due within N days
