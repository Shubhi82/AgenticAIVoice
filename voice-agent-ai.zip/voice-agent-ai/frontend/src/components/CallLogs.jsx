// ─── CallLogs.jsx ──────────────────────────────────────────────────────────
import { useState, useEffect } from "react";
import { apiService } from "../services/apiService";

export function CallLogs() {
  const [logs, setLogs]     = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiService.getCallLogs()
      .then(d => setLogs(d.logs || []))
      .finally(() => setLoading(false));
  }, []);

  const DECISION_COLORS = {
    PAYMENT_PROMISED: "#22c55e", NEED_EXTENSION: "#fbbf24",
    REFUSED: "#ef4444", ESCALATE_HUMAN: "#f97316",
    NO_ANSWER: "#64748b", initiated: "#3b82f6",
  };

  return (
    <div>
      <h2 style={{ margin: "0 0 20px", fontSize: 20, fontWeight: 700 }}>
        📋 Call History ({logs.length})
      </h2>
      {loading ? (
        <div style={{ color: "#64748b", textAlign: "center", padding: 40 }}>Loading...</div>
      ) : logs.length === 0 ? (
        <div style={{ background: "#1e293b", borderRadius: 12, padding: 40, textAlign: "center", color: "#64748b" }}>
          No calls made yet. Go to Customers and click Call to start.
        </div>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#1e293b", borderBottom: "2px solid #334155" }}>
              {["#", "Customer ID", "Called At", "Transcript", "Decision", "Outcome", "Call SID"].map(h => (
                <th key={h} style={{
                  padding: "10px 14px", textAlign: "left",
                  fontSize: 11, color: "#94a3b8", fontWeight: 600
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {logs.map((log, i) => (
              <tr key={log.id} style={{
                background: i % 2 === 0 ? "#0f172a" : "#111827",
                borderBottom: "1px solid #1e293b"
              }}>
                <td style={{ padding: "12px 14px", color: "#64748b", fontSize: 12 }}>{log.id}</td>
                <td style={{ padding: "12px 14px", fontWeight: 600 }}>{log.customer_id}</td>
                <td style={{ padding: "12px 14px", color: "#94a3b8", fontSize: 12 }}>{log.called_at}</td>
                <td style={{ padding: "12px 14px", color: "#94a3b8", fontSize: 12, maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis" }}>
                  {log.transcript || "—"}
                </td>
                <td style={{ padding: "12px 14px" }}>
                  <span style={{
                    background: `${DECISION_COLORS[log.decision] || "#94a3b8"}22`,
                    color: DECISION_COLORS[log.decision] || "#94a3b8",
                    border: `1px solid ${DECISION_COLORS[log.decision] || "#94a3b8"}55`,
                    borderRadius: 12, padding: "2px 10px", fontSize: 11, fontWeight: 600
                  }}>
                    {log.decision || "—"}
                  </span>
                </td>
                <td style={{ padding: "12px 14px", color: "#94a3b8", fontSize: 12 }}>{log.outcome}</td>
                <td style={{ padding: "12px 14px", color: "#64748b", fontSize: 11, fontFamily: "monospace" }}>
                  {log.call_sid ? log.call_sid.slice(0, 16) + "..." : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
export default CallLogs;


// ─── UploadData.jsx ────────────────────────────────────────────────────────
export function UploadData() {
  const [file, setFile]       = useState(null);
  const [result, setResult]   = useState(null);
  const [loading, setLoading] = useState(false);

  async function upload() {
    if (!file) return;
    setLoading(true); setResult(null);
    try {
      const r = await apiService.uploadCSV(file);
      setResult({ success: true, ...r });
    } catch (e) {
      setResult({ success: false, error: e.message });
    }
    setLoading(false);
  }

  async function loadSample() {
    setLoading(true); setResult(null);
    try {
      const r = await apiService.loadSample();
      setResult({ success: true, ...r });
    } catch (e) {
      setResult({ success: false, error: e.message });
    }
    setLoading(false);
  }

  return (
    <div>
      <h2 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700 }}>📁 Upload Customer Data</h2>
      <p style={{ color: "#64748b", margin: "0 0 28px", fontSize: 14 }}>
        Upload any CSV with customer loan data (from Kaggle or your own)
      </p>

      {/* Required columns */}
      <div style={{ background: "#1e293b", borderRadius: 12, padding: 24, marginBottom: 20, border: "1px solid #334155" }}>
        <div style={{ fontWeight: 600, marginBottom: 12 }}>Required CSV Columns</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {["customer_id","name","phone","emi_amount","emi_due_date"].map(col => (
            <span key={col} style={{
              background: "#dc2626", color: "#fff", borderRadius: 6,
              padding: "3px 10px", fontSize: 12, fontWeight: 600
            }}>{col}</span>
          ))}
        </div>
        <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap" }}>
          <span style={{ fontSize: 12, color: "#64748b" }}>Optional:</span>
          {["email","loan_amount","last_payment_date","missed_payments","risk_score","status"].map(col => (
            <span key={col} style={{
              background: "#1e3a5f", color: "#60a5fa", borderRadius: 6,
              padding: "3px 10px", fontSize: 12
            }}>{col}</span>
          ))}
        </div>
      </div>

      {/* Upload area */}
      <div style={{ background: "#1e293b", borderRadius: 12, padding: 32, border: "2px dashed #334155", textAlign: "center", marginBottom: 20 }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>📊</div>
        <div style={{ color: "#94a3b8", marginBottom: 16 }}>
          Upload a CSV from Kaggle (e.g. Home Credit, Give Me Some Credit) or your own dataset
        </div>
        <input
          type="file"
          accept=".csv"
          onChange={e => setFile(e.target.files[0])}
          style={{ marginBottom: 16 }}
        />
        {file && <div style={{ color: "#60a5fa", marginBottom: 16 }}>📄 {file.name}</div>}
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          <button onClick={upload} disabled={!file || loading} style={{
            background: "#1d4ed8", color: "#fff", border: "none",
            borderRadius: 8, padding: "12px 28px", cursor: !file ? "not-allowed" : "pointer",
            fontSize: 14, fontWeight: 600
          }}>
            {loading ? "Uploading..." : "📤 Upload CSV"}
          </button>
          <button onClick={loadSample} disabled={loading} style={{
            background: "#1e293b", color: "#a78bfa", border: "1px solid #7c3aed",
            borderRadius: 8, padding: "12px 24px", cursor: "pointer", fontSize: 14
          }}>
            🎯 Load Sample Data
          </button>
        </div>
      </div>

      {result && (
        <div style={{
          background: result.success ? "#14532d22" : "#7f1d1d22",
          border: `1px solid ${result.success ? "#22c55e" : "#ef4444"}`,
          borderRadius: 8, padding: "16px 20px",
          color: result.success ? "#22c55e" : "#ef4444"
        }}>
          {result.success
            ? `✅ Imported ${result.imported} customers (${result.skipped} skipped)`
            : `❌ ${result.error}`}
        </div>
      )}
    </div>
  );
}
